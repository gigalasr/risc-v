tools/vhdlmake/build/vhdlmake run sign_extension_tb
tools/vhdlmake/build/vhdlmake run decoder_tb
tools/vhdlmake/build/vhdlmake run register_file_tb
tools/vhdlmake/build/vhdlmake run single_port_ram_tb
tools/vhdlmake/build/vhdlmake run gen_mux_tb
tools/vhdlmake/build/vhdlmake run pipeline_register_tb
tools/vhdlmake/build/vhdlmake run alu_tb