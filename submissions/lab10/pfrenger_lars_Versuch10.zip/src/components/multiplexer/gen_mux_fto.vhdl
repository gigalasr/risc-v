-- Laboratory RA solutions/versuch1
-- Sommersemester 25
-- Group Details
-- Lab Date:
-- 1. Participant First and Last Name: Lars Pfrenger
-- 2. Participant First and Last Name: Rouven Schönigt

library IEEE;
use IEEE.STD_LOGIC_1164.ALL;
use work.constant_package.ALL;

entity gen_mux_fto is 
    generic(
        data_width : integer := DATA_WIDTH_GEN
    );
    port (
        pi_sel : in std_logic_vector(1 downto 0) := (others => '0');

        pi_a : in std_logic_vector(data_width - 1 downto 0) := (others => '0');
        pi_b : in std_logic_vector(data_width - 1 downto 0) := (others => '0');
        pi_c : in std_logic_vector(data_width - 1 downto 0) := (others => '0');
        pi_d : in std_logic_vector(data_width - 1 downto 0) := (others => '0');

        po_res : out std_logic_vector(data_width - 1 downto 0) := (others => '0')
    );
end entity gen_mux_fto;

architecture behavior of gen_mux_fto is begin
    with pi_sel select
        po_res <=
        pi_a when "00",
        pi_b when "01",
        pi_c when "10",
        pi_d when "11",
        (others => '0') when others; 
end architecture behavior;


